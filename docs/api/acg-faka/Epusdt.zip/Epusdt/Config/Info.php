<?php
declare (strict_types = 1);

return [
    'version'     => '1.0.1',
    'name'        => 'BEpusdt',
    'author'      => 'v03413',
    'website'     => 'https://github.com/v03413/BEpusdt',
    'description' => 'BEpusdt 一款更好用的个人加密货币收款网关',
    'options'     => [
        'USDT' => 'USDT',
        'USDC' => 'USDC',
        'TRX'  => 'TRX',
        'BNB'  => 'BNB',
        'ETH'  => 'ETH',
    ],
    'callback'    => [
        \App\Consts\Pay::IS_SIGN            => true,
        \App\Consts\Pay::IS_STATUS          => true,
        \App\Consts\Pay::FIELD_STATUS_KEY   => 'status',
        \App\Consts\Pay::FIELD_STATUS_VALUE => 2,
        \App\Consts\Pay::FIELD_ORDER_KEY    => 'order_id',
        \App\Consts\Pay::FIELD_AMOUNT_KEY   => 'amount',
        \App\Consts\Pay::FIELD_RESPONSE     => 'ok'
    ]
];