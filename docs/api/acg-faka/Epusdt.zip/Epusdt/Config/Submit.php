<?php
declare (strict_types = 1);

return [
    [
        "title"       => "支付网关",
        "name"        => "url",
        "type"        => "input",
        "placeholder" => "支付网关地址"
    ],
    [
        "title"       => "对接密钥",
        "name"        => "key",
        "type"        => "input",
        "placeholder" => "密钥"
    ],
    [
        "title"       => "法币单位",
        "name"        => "fiat",
        "type"        => "select",
        "placeholder" => "商品计价的法币单位",
        "default"     => "CNY",
        "dict"        => [
            ["id" => "CNY", "name" => "CNY 人民币"],
            ["id" => "USD", "name" => "USD 美元"],
            ["id" => "EUR", "name" => "EUR 欧元"],
            ["id" => "JPY", "name" => "JPY 日元"],
            ["id" => "GBP", "name" => "GBP 英镑"],
        ]
    ]

];